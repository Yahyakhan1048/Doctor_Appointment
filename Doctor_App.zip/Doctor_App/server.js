import express from "express";

import morgan from "morgan"; // this package tell us which request has been hit
import connectDB from "./config/db.js";
import userRoute from "./routes/userRoutes.js";
import adminRoute from "./routes/adminRoute.js";
import doctorRoute from "./routes/doctorRoute.js";
import dotenv from "dotenv";
import colors from "colors";
import cors from "cors";
// Configure env

dotenv.config();

// rest object
const app = express();
// Connect databae

connectDB();
// middleware
app.use(cors());
app.use(express.json());
app.use(morgan("dev"));

// routes

app.use("/api/v1/user", userRoute);
app.use("/api/v1/admin", adminRoute);
app.use("/api/v1/doctor", doctorRoute);
//-----------------

app.get("/", (req, res) => {
  res.send("<h1>Welcome to Doctor App</h1>");
});

// server listening port

const PORT = process.env.PORT || 8080;

app.listen(PORT, () => {
  console.log(
    `Server is running on ${process.env.DEV_MODE} on port ${PORT}`.bgGreen.white
      .bold
  );
});
