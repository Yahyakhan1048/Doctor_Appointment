import doctorModel from "../models/doctorModel.js";
import userModel from "../models/userModel.js";

export const getAllUsersController = async (req, res) => {
  try {
    const users = await userModel.find({});
    res.status(200).send({
      success: true,
      message: "All users Data list",
      data: users,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error while fetching Users",
      error,
    });
  }
};

export const getAllDoctorsController = async (req, res) => {
  try {
    const doctors = await doctorModel.find({});
    res.status(200).send({
      success: true,
      message: "All users Data list",
      data: doctors,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error while fetching Doctors",
      error,
    });
  }
};

//============= changing Doctor Account status  =========

export const changeAccountStatusController = async (req, res) => {
  try {
    // Destructure the request body into doctorId and status
    const { doctorId, status } = req.body;
    // We don't need to destructure userId because we can get it from the doctor document
    // using the doctorId

    // Find the doctor document by id and update its status
    const doctor = await doctorModel.findByIdAndUpdate(doctorId, { status });

    // Find the user document associated with the doctor
    const user = await userModel.findOne({ _id: doctor.userId });

    // Add a new notification to the user's notification array
    const notification = user.notification;
    notification.push({
      type: "doctor-account-request-updated",
      message: `Your Doctor Account request has ${status}`,
      onClickPath: "/notification",
    });
    user.isDoctor = status === "approved" ? true : false;
    // Save the updated user document
    await user.save();

    // Send a success response back to the frontend
    res.status(200).send({
      success: true,
      message: "Account status Updated",
      data: doctor,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error in account status",
      error,
    });
  }
};
