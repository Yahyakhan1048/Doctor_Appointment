import { comparePassword, hashPassword } from "../helpers/authHelper.js";
import appointmentModel from "../models/appointmentModel.js";
import doctorModel from "../models/doctorModel.js";
import userModel from "../models/userModel.js";
import moment from "moment";
import JWT from "jsonwebtoken";
export const registerController = async (req, res) => {
  try {
    const { name, email, password } = req.body;
    // validation
    if (!name) {
      return res.send({ message: "Name is required" });
    }
    if (!email) {
      return res.send({ message: "Email is required" });
    }
    if (!password) {
      return res.send({ message: "Password is required" });
    }
    // Checking exsiting user
    const exisitingUser = await userModel.findOne({ email });
    if (exisitingUser) {
      return res.status(200).send({
        success: false,
        message: "Already Register Please Login",
      });
    }

    // register user
    // Getting this password from user and sent them to the autHelper hashPassword function to hash them
    const hashedPassword = await hashPassword(password);

    // saving the user and getting the data in frontent using this user variable user
    const newUser = await new userModel({
      name,
      email,
      password: hashedPassword,
    }).save();
    res.status(201).send({
      success: true,
      message: "User Registered Successully",
      newUser, //  ------ This is passing the user
    });
    // ===================
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error in Registration",
      error,
    });
  }
};

// POST Login Controller

export const loginController = async (req, res) => {
  try {
    const { email, password } = req.body;
    // validation
    if (!email || !password) {
      return res.status(404).send({
        success: false,
        message: "Invalid email or Password",
      });
    }
    // check user
    const user = await userModel.findOne({ email });
    if (!user) {
      return res.status(404).send({
        success: false,
        message: "Email is not registered",
      });
    }
    // comparing password that taken from user with database password
    const match = await comparePassword(password, user.password);
    if (!match) {
      return res.status(200).send({
        success: false,
        message: "Incorrect Password",
      });
    }
    // Creating JSON WEB token
    const token = await JWT.sign({ _id: user._id }, process.env.JWT_SECRET, {
      expiresIn: "7d", // it mean after 7 days user must be need to login again
    });
    res.status(200).send({
      success: true,
      message: "Login Successfully",
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
      //   sending token
      token,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error in login",
      error,
    });
  }
};

// ========== authentication controller ========

export const authController = async (req, res) => {
  try {
    if (!req.body.userId) {
      return res
        .status(200)
        .send({ message: "User ID is required", success: false });
    }
    const user = await userModel.findById({ _id: req.body.userId });
    user.password = undefined;
    if (!user) {
      return res
        .status(200)
        .send({ message: "user not found", success: false });
    } else {
      res.status(200).send({ success: true, data: user });
    }
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Auth error",
      error,
    });
  }
};

// ====== Apply for Doctor ==============
export const applyDoctorController = async (req, res) => {
  try {
    // Get all data from the form request body
    const newDoctor = await doctorModel({ ...req.body, status: "pending" });

    // Save the new doctor document to the database
    await newDoctor.save();

    // Notify the admin that a new doctor application has been received
    const adminUser = await userModel.findOne({ isAdmin: true });
    const notification = adminUser.notification;
    notification.push({
      type: "apply-doctor-request",
      message: `${newDoctor.firstName} ${newDoctor.lastName} has applied for a doctor`,
      data: {
        doctorId: newDoctor._id,
        name: newDoctor.firstName + " " + newDoctor.lastName,
        onClickPath: "/admin/doctors", // redirect to the doctors page
      },
    });

    // Update the admin's notification array
    await userModel.findByIdAndUpdate(adminUser._id, { notification });

    // Send a success response to the client
    res
      .status(201)
      .send({ success: true, message: "Doctor account applied Successfully" });
  } catch (error) {
    console.log(error);
    res
      .status(500)
      .send({ success: false, message: "Error while apply for Doctor", error });
  }
};

//============= notification controller ===========

export const getAllNotificationController = async (req, res) => {
  try {
    // Find the user document by ID
    const user = await userModel.findOne({ _id: req.body.userId });

    // Get the seen notification array
    const seennotification = user.seennotification;

    // Get the notification array
    const notification = user.notification;

    // Add all notifications to the seen notification array
    seennotification.push(...notification);
    // Update the user document with the new seen notification array
    await userModel.findByIdAndUpdate(user._id, { $set: { seennotification } });

    // Clear the notification array
    user.notification = [];

    // Assign the updated notification array to seen notification
    user.seennotification = notification;

    // Save the updated user document
    const updatedUser = await user.save();

    // Send a success response with the updated user data
    res.status(200).send({
      success: true,
      message: "All notification mark as read",
      data: updatedUser,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error in notification",
      error,
    });
  }
};

export const deleteAllNotificationController = async (req, res) => {
  try {
    const user = await userModel.findOne({ _id: req.body.userId });
    //  clear notification and seennotifiation arry
    (user.notification = []), (user.seennotification = []);
    const updatedUser = await user.save(); // to update the user schema
    // to hide the password
    updatedUser.password = undefined;
    res.status(200).send({
      success: true,
      message: "Notification Deleted Successfully",
      data: updatedUser,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "unable to delete all notification",
      error,
    });
  }
};

//============ Getting all Doctor =============

export const getAllDoctorController = async (req, res) => {
  try {
    const doctors = await doctorModel.find({ status: "approved" });
    res.status(200).send({
      success: true,
      message: "Doctor list fetch Successfully",
      data: doctors,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "unable to delete all notification",
      error,
    });
  }
};

//========== Book Appointment ============
export const bookAppointmentController = async (req, res) => {
  try {
    req.body.date = moment(req.body.date, "DD-MM-YYYY").toISOString();
    req.body.time = moment(req.body.time, "HH:mm").toISOString();
    req.body.status = "pending";
    const newAppointment = new appointmentModel(req.body);
    await newAppointment.save();
    const user = await userModel.findOne({ _id: req.body.doctorInfo.userId });

    user.notification.push({
      type: "New-appointment-request",
      message: `A nEw Appointment Request from ${req.body.userInfo.name}`,
      onCLickPath: "/user/appointments",
    });
    await user.save();
    res.status(200).send({
      success: true,
      message: "Appointment Book succesfully",
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      error,
      message: "Error While Booking Appointment",
    });
  }
};

//========== Booking Avaliability Controller =========

export const bookingAvalibilityController = async (req, res) => {
  try {
    // Convert the date string to a ISO format
    const date = moment(req.body.date, "DD-MM-YYYY").toISOString();

    // Convert the time string to a ISO format and subtract(delay) 1 hour
    const fromTime = moment(req.body.time, "HH:mm")
      .subtract(1, "hours")
      .toISOString();

    // Convert the time string to a ISO format and subtract 1 hour
    const toTime = moment(req.body.time, "HH:mm").add(1, "hours").toISOString();

    // Get the doctorId from the request body
    const doctorId = req.body.doctorId;

    // Find appointments with the same doctorId, date, and time range
    const appointments = await appointmentModel.find({
      doctorId,
      date,
      time: {
        $gte: fromTime, // greater than or equal to fromTime
        $lte: toTime, // less than or equal to toTime
      },
    });

    // If appointments are found, return a success=false message
    if (appointments.length > 0) {
      return res.status(200).send({
        success: true,
        message: "Appointment not avaliable at this time",
      });
    }

    // If no appointments are found, return a success=true message
    else {
      return res.status(200).send({
        success: true,
        message: "Appointment Booked Successfully",
      });
    }
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Failed booking avaliability",
      error,
    });
  }
};

//=========== Appointment list =========

export const userAppointmentsController = async (req, res) => {
  try {
    const appointments = await appointmentModel.find({
      userId: req.body.userId,
    });
    res.status(200).send({
      success: true,
      message: "Fetch User appointment list Successfully",
      data: appointments,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Failed to fetch user appointment list",
      error,
    });
  }
};
