import React, { useEffect } from "react"; // Import React and useEffect from the react package
import { Navigate } from "react-router-dom"; // Import Navigate from the react-router-dom package
import { useSelector, useDispatch } from "react-redux"; // Import useSelector and useDispatch from the react-redux package
import { showLoading } from "../redux/features/alertSlice"; // Import showLoading from the alertSlice redux feature
import axios from "axios"; // Import axios for making API requests
import { setUser } from "../redux/features/userSlice"; // Import setUser from the userSlice redux feature

// Define the hideLoading action creator
export const hideLoading = () => (dispatch) => {
  setTimeout(() => {
    dispatch({ type: "alerts/hideLoading" }); // Dispatch the hideLoading action after a 1-second delay
  }, 1000);
};

// Define the ProtectedRoute component
const ProtectedRoute = ({ children }) => {
  const dispatch = useDispatch(); // Get the dispatch function from the redux store
  const { user, isLoading } = useSelector((state) => state.user); // Get the user and isLoading state from the redux store

  // Define the getUser function
  // eslint-disable-next-line
  const getUser = async () => {
    try {
      dispatch(showLoading()); // Show the loading indicator
      const res = await axios.post(
        // Make a POST request to the API
        "/api/v1/user/getUserData",
        { token: localStorage.getItem("token") }, // Pass the token in the request body
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`, // Set the Authorization header with the token
          },
        }
      );
      dispatch(hideLoading()); // Hide the loading indicator
      if (res.data.success) {
        dispatch(setUser(res.data.data)); // Set the user data in the redux store
      } else {
        <Navigate to="/login" />; // Navigate to the login page if the API request fails
        localStorage.clear();
      }
    } catch (error) {
      dispatch(hideLoading()); // Hide the loading indicator on error
      localStorage.clear();
      console.log(error); // Log the error
    }
  };

  // Use the useEffect hook to call the getUser function when the component mounts
  useEffect(() => {
    if (!user && !isLoading) {
      getUser();
    }
  }, [user, isLoading, getUser]);

  // Render the protected content if the user is authenticated
  if (localStorage.getItem("token")) {
    return children;
  } else {
    return <Navigate to="/login" />; // Navigate to the login page if the user is not authenticated
  }
};

export default ProtectedRoute; // Export the ProtectedRoute component
