import express from "express";
import {
  applyDoctorController,
  authController,
  bookAppointmentController,
  bookingAvalibilityController,
  deleteAllNotificationController,
  getAllDoctorController,
  getAllNotificationController,
  loginController,
  registerController,
  userAppointmentsController,
} from "../controllers/userController.js";

import AuthMiddleware from "./../middlewares/Authmiddleware.js";

const router = express.Router();

//======= Routes =========

// ------ post // register ----------
router.post("/register", registerController);
// ------ post // login ---------
router.post("/login", loginController);

// Auth || post
router.post("/getUserData", AuthMiddleware, authController);
// Apply Doctor || post
router.post("/apply-doctor", AuthMiddleware, applyDoctorController);

// Notification Doctor || post
router.post(
  "/get-all-notification",
  AuthMiddleware,
  getAllNotificationController
);

// Notification Doctor || post
router.post(
  "/delete-all-notification",
  AuthMiddleware,
  deleteAllNotificationController
);

// ======== Getting All doctor  ==========
router.get("/getAllDoctors", AuthMiddleware, getAllDoctorController);
//=========== Book appointment =============

router.post("/book-appointment", AuthMiddleware, bookAppointmentController);

//========= Booking Avaliability ==========

router.post(
  "/booking-avalibility",
  AuthMiddleware,
  bookingAvalibilityController
);

//========== Appointment List ===========
router.get("/user-appointments", AuthMiddleware, userAppointmentsController);
export default router;
