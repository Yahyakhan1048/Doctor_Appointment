import express from "express";
import AuthMiddleware from "../middlewares/Authmiddleware.js";
import {
  doctorappointmentControllers,
  getDoctorByIdController,
  getDoctorInfoController,
  updateProileController,
  updateStatusController,
} from "../controllers/doctorController.js";
const router = express.Router();

// ========== Routes =======

//==== posting Single Doctor info

router.post("/getDoctorInfo", AuthMiddleware, getDoctorInfoController);

//==== update profile =========

router.post("/updateProfile", AuthMiddleware, updateProileController);

//======== Getting single doc info

router.post("/getDoctorById", AuthMiddleware, getDoctorByIdController);

//   Doctor appointment

router.get(
  "/doctor-appointments",
  AuthMiddleware,
  doctorappointmentControllers
);

//======== Update Status ======
router.post("/update-status", AuthMiddleware, updateStatusController);

export default router;
