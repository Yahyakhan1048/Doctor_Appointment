import exprss from "express";
import Authmiddleware from "../middlewares/Authmiddleware.js";
import {
  changeAccountStatusController,
  getAllDoctorsController,
  getAllUsersController,
} from "../controllers/adminController.js";

const router = exprss.Router();

// ---------- Getting all user -----

router.get("/getAllUsers", Authmiddleware, getAllUsersController);

//---------- Getting all doctor ----

router.get("/getAllDoctors", Authmiddleware, getAllDoctorsController);

//======= Changing account status from approve

router.post(
  "/changeAccountStatus",
  Authmiddleware,
  changeAccountStatusController
);

export default router;
